# DroneSim Android

A Kotlin Android camera-overlay **simulation**. The rear camera view stays stationary while virtual flight telemetry changes.

## Requirements
- Android Studio (recent stable release)
- Android SDK 35
- Internet access on the first Gradle sync to download dependencies
- Android 8.0 (API 26) or newer device with a rear camera

## Open and build
1. Extract this ZIP.
2. In Android Studio, choose **Open** and select the `DroneSimAndroid` folder.
3. Allow Gradle to sync and download dependencies.
4. Connect an Android phone, enable Developer options/USB debugging, and press **Run**.
5. Grant camera permission when prompted.

To create an APK, select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio will show the output location when finished.

## Controls
- Tap **START SIM** to start simulated telemetry.
- Drag the left joystick to simulate direction and heading changes.
- Drag the right-side throttle slider up/down to simulate throttle and altitude.
- Tap **STOP SIM** to stop the simulation.

## Important
This is a visual simulation only. It does not estimate real-world drone position, does not make the live camera view move, and cannot control a physical drone. Altitude, speed, heading, and battery are illustrative simulated values. Do not use them for real flight or navigation.
