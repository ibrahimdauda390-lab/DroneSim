package com.example.dronesim

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Camera-stationary drone simulator HUD.
 * Joystick input changes simulated telemetry only; it does not move the real camera
 * or control a physical drone.
 */
class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var running = false
    private var cameraUnavailable = false
    private var lastTick = System.currentTimeMillis()

    private var altitude = 0.0f
    private var speed = 0.0f
    private var battery = 100.0f
    private var heading = 0.0f
    private var throttle = 0.0f

    private var joystickPointer = -1
    private var joyX = 0.0f
    private var joyY = 0.0f
    private var joyCenterX = 0.0f
    private var joyCenterY = 0.0f
    private var joyRadius = 0.0f

    private var throttlePointer = -1
    private var throttleY = 0.0f
    private var throttleTop = 0.0f
    private var throttleBottom = 0.0f
    private var throttleX = 0.0f

    private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xBB07131D.toInt()
    }

    init {
        isClickable = true
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    fun setCameraUnavailable(unavailable: Boolean) {
        cameraUnavailable = unavailable
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        // Light center reticle
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.2f
        paint.color = 0xEFFFFFFF.toInt()
        val cx = w * 0.5f
        val cy = h * 0.48f
        canvas.drawCircle(cx, cy, 24f, paint)
        canvas.drawLine(cx - 42f, cy, cx - 12f, cy, paint)
        canvas.drawLine(cx + 12f, cy, cx + 42f, cy, paint)
        canvas.drawLine(cx, cy - 42f, cx, cy - 12f, paint)
        canvas.drawLine(cx, cy + 12f, cx, cy + 42f, paint)

        // Top telemetry panel
        canvas.drawRoundRect(RectF(18f, 16f, w - 18f, 88f), 14f, 14f, panel)
        paint.style = Paint.Style.FILL
        paint.color = 0xFFFFFFFF.toInt()
        paint.textSize = 15f
        paint.isFakeBoldText = true
        canvas.drawText(if (running) "DRONESIM  •  SIMULATION ACTIVE" else "DRONESIM  •  READY", 34f, 40f, paint)
        paint.isFakeBoldText = false
        paint.textSize = 13f
        canvas.drawText("ALT  ${altitude.toInt()} m", 34f, 66f, paint)
        canvas.drawText("SPD  ${"%.1f".format(speed)} m/s", 160f, 66f, paint)
        canvas.drawText("HDG  ${heading.toInt().toString().padStart(3, '0')}°", 300f, 66f, paint)
        canvas.drawText("BAT  ${battery.toInt()}%", 420f, 66f, paint)

        // Battery meter
        val bx = w - 112f
        val by = 52f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = 0xFFFFFFFF.toInt()
        canvas.drawRoundRect(RectF(bx, by - 9f, bx + 64f, by + 9f), 3f, 3f, paint)
        canvas.drawRect(bx + 64f, by - 4f, bx + 69f, by + 4f, paint)
        paint.style = Paint.Style.FILL
        paint.color = if (battery > 20) 0xFF5BE39D.toInt() else 0xFFFF625D.toInt()
        canvas.drawRoundRect(RectF(bx + 3f, by - 6f, bx + 3f + 58f * battery / 100f, by + 6f), 2f, 2f, paint)

        // Joystick at bottom-left
        joyCenterX = w * 0.17f
        joyCenterY = h * 0.77f
        joyRadius = min(w, h) * 0.13f
        paint.style = Paint.Style.FILL
        paint.color = 0x7707131D
        canvas.drawCircle(joyCenterX, joyCenterY, joyRadius, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = 0xDFFFFFFF.toInt()
        canvas.drawCircle(joyCenterX, joyCenterY, joyRadius, paint)
        canvas.drawCircle(joyCenterX, joyCenterY, joyRadius * 0.55f, paint)
        canvas.drawLine(joyCenterX - joyRadius, joyCenterY, joyCenterX + joyRadius, joyCenterY, paint)
        canvas.drawLine(joyCenterX, joyCenterY - joyRadius, joyCenterX, joyCenterY + joyRadius, paint)
        paint.style = Paint.Style.FILL
        paint.color = 0xFF44D7C8.toInt()
        val knobX = joyCenterX + joyX * joyRadius
        val knobY = joyCenterY + joyY * joyRadius
        canvas.drawCircle(knobX, knobY, joyRadius * 0.22f, paint)
        paint.color = 0xFFFFFFFF.toInt()
        paint.textSize = 12f
        canvas.drawText("DIRECTION", joyCenterX - 33f, joyCenterY + joyRadius + 20f, paint)

        // Throttle slider at bottom-right
        throttleX = w * 0.84f
        throttleTop = h * 0.58f
        throttleBottom = h * 0.88f
        if (throttleY == 0f) throttleY = throttleBottom - throttle * (throttleBottom - throttleTop)
        paint.style = Paint.Style.FILL
        paint.color = 0x7707131D
        canvas.drawRoundRect(RectF(throttleX - 24f, throttleTop - 14f, throttleX + 24f, throttleBottom + 14f), 18f, 18f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = 0xDFFFFFFF.toInt()
        canvas.drawLine(throttleX, throttleTop, throttleX, throttleBottom, paint)
        paint.style = Paint.Style.FILL
        paint.color = 0xFFFFC857.toInt()
        canvas.drawCircle(throttleX, throttleY.coerceIn(throttleTop, throttleBottom), 13f, paint)
        paint.color = 0xFFFFFFFF.toInt()
        paint.textSize = 12f
        canvas.drawText("THROTTLE", throttleX - 30f, throttleBottom + 34f, paint)
        paint.textSize = 11f
        canvas.drawText("UP", throttleX - 9f, throttleTop - 22f, paint)
        canvas.drawText("DOWN", throttleX - 18f, throttleBottom + 50f, paint)

        // Start/stop control
        val button = RectF(w * 0.40f, h * 0.83f, w * 0.60f, h * 0.93f)
        paint.style = Paint.Style.FILL
        paint.color = if (running) 0xFFDC4C4C.toInt() else 0xFF168C72.toInt()
        canvas.drawRoundRect(button, 14f, 14f, paint)
        paint.color = 0xFFFFFFFF.toInt()
        paint.textSize = 15f
        paint.isFakeBoldText = true
        val label = if (running) "STOP SIM" else "START SIM"
        canvas.drawText(label, button.centerX() - paint.measureText(label) / 2f, button.centerY() + 5f, paint)
        paint.isFakeBoldText = false

        if (cameraUnavailable) {
            paint.color = 0xEE07131D.toInt()
            canvas.drawRoundRect(RectF(w * .25f, h * .38f, w * .75f, h * .58f), 14f, 14f, paint)
            paint.color = 0xFFFFFFFF.toInt()
            paint.textSize = 15f
            val msg = "Camera unavailable — check permission"
            canvas.drawText(msg, w / 2f - paint.measureText(msg) / 2f, h * .49f, paint)
        }

        if (running) updateSimulation()
        postInvalidateDelayed(100)
    }

    private fun updateSimulation() {
        val now = System.currentTimeMillis()
        val dt = ((now - lastTick).coerceAtMost(250L) / 1000f)
        lastTick = now
        altitude = (altitude + (throttle - 0.35f) * 2.0f * dt).coerceIn(0f, 120f)
        val targetSpeed = hypot(joyX, joyY) * 12f
        speed += (targetSpeed - speed) * min(1f, dt * 2.5f)
        heading = (heading + joyX * 22f * dt + 360f) % 360f
        battery = max(0f, battery - (0.012f + throttle * 0.025f) * dt)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        val w = width.toFloat()
        val h = height.toFloat()
        val button = RectF(w * 0.40f, h * 0.83f, w * 0.60f, h * 0.93f)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val index = event.actionIndex
                val px = event.getX(index)
                val py = event.getY(index)
                if (button.contains(px, py)) {
                    running = !running
                    lastTick = System.currentTimeMillis()
                    if (!running) speed = 0f
                } else if (px < w * 0.38f && py > h * 0.48f) {
                    joystickPointer = event.getPointerId(index)
                    updateJoystick(px, py)
                } else if (px > w * 0.70f && py > h * 0.45f) {
                    throttlePointer = event.getPointerId(index)
                    updateThrottle(py)
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    when (event.getPointerId(i)) {
                        joystickPointer -> updateJoystick(event.getX(i), event.getY(i))
                        throttlePointer -> updateThrottle(event.getY(i))
                    }
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val index = event.actionIndex
                val id = event.getPointerId(index)
                if (id == joystickPointer) {
                    joystickPointer = -1
                    joyX = 0f
                    joyY = 0f
                }
                if (id == throttlePointer) throttlePointer = -1
                invalidate()
                return true
            }
        }
        return true
    }

    private fun updateJoystick(x: Float, y: Float) {
        val dx = x - joyCenterX
        val dy = y - joyCenterY
        val distance = max(1f, hypot(dx, dy))
        val scale = min(1f, joyRadius / distance)
        joyX = dx / joyRadius * scale
        joyY = dy / joyRadius * scale
    }

    private fun updateThrottle(y: Float) {
        throttleY = y.coerceIn(throttleTop, throttleBottom)
        throttle = 1f - ((throttleY - throttleTop) / (throttleBottom - throttleTop))
    }
}
